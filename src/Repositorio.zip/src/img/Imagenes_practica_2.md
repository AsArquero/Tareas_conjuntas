## Imágenes para la práctica 2
# Imagen 1
- ![IMAGEN_1](https://user-images.githubusercontent.com/90325763/142302402-d118b3cc-2845-48ee-a52f-27da9fc3f61d.png)
# Imagen 2
- ![IMAGEN_2](https://user-images.githubusercontent.com/90325763/142302405-828bb6b3-6e21-4547-8cf4-54c2d92bf365.png)
# Imagen 3
- ![IMAGEN_3](https://user-images.githubusercontent.com/90325763/142302413-55066c6a-8f25-47e4-b750-1aca55984e09.png)
# Imagen 4
- ![IMAGEN_4](https://user-images.githubusercontent.com/90325763/142302417-870d07ac-c568-4653-9e03-5a8c5cba14b4.png)
