## Imágenes para la práctica 1

![USA](https://user-images.githubusercontent.com/90325763/145458814-fc5e1bb5-69bb-46cd-9323-91fe53a5d854.jpg)