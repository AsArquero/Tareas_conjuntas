## IMÁGENES PARA LA TAREA 4
![Porcentaje-de-poblacio-n-extranjera-en-los-barrios-de-madrid](https://user-images.githubusercontent.com/90325763/143934255-697b9079-4186-43f5-b179-63e3c95a9178.png)
![jEUlI-renta-media-por-familia-2017-](https://user-images.githubusercontent.com/90325763/144118372-0f1e976d-8a9f-42e7-ba75-0f4f6ac40cd2.png)
![4JxLz-relaci-n-entre-la-renta-media-por-hogar-y-la-poblaci-n-migrante-en-los-barrios-de-madrid](https://user-images.githubusercontent.com/90325763/144118379-2c2ce963-9fe3-42ec-b6cc-cb4251496776.png)
