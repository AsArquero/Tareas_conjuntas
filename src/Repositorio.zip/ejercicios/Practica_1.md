# INFOGRAFÍA
- HISTORIA DE EEUU (INDEPENDENCIA Y GUERRA CIVIL)

![USA](https://user-images.githubusercontent.com/90325763/145458814-fc5e1bb5-69bb-46cd-9323-91fe53a5d854.jpg)

He seleccionado esta infografía porque, a pesar de la sencillez de sus dibujos, utiliza un gran número de datos numéricos (proporcionando una importante cantidad de información al lector sin que por ello resulte pesada). El uso de colores me parece también muy atractivo y acertado (curiosamente, el rojo y el azul vuelven a enfrentarse). Un detalle importante es que esta infografía me ha recordado mucho al estilo empleado en numerosos vídeos y libros de divulgación. El libro de ilustraciones "Prisioneros de la geografía" (Marshal T., Easton G, Smith J.; 2020) y canales de Youtube como "Crash Course" (https://www.youtube.com/user/crashcourse) utilizan estilos de ilustración similares.


